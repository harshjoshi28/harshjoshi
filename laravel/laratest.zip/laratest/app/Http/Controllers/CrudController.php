<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\register;

class CrudController extends Controller
{
    public function addItem(Request $request)
    {
        $imagePath = $request -> file('product_image')->store('images/','public');
        
        $a = new Product();
        $a -> product_name = $request->product_name;
        $a -> product_price = $request->product_price;
        $a -> product_image = $imagePath;
        $a -> save();
        return redirect('/addrec');
    }
    public function list()
    {
        $data = Product::all();
        //dd($data);
        return view('showrec',['data'=>$data]);
    }
   public function delete($id)
    {
        $a = Product::find($id);
        $a -> delete();
        return redirect('/showrec');
    }
    public function edit($id)
    {
        $a = Product::find($id);
        return view('edit',['data'=>$a]);
    }
    public function editaction(Request $request)
    {
        $a = Product::find($request->id);
        $imagePath = $request -> file('product_image')->store('images/','public');
        $a -> product_name = $request->product_name;
        $a -> product_price = $request->product_price;
        $a -> product_image = $imagePath;
        $a -> save();
        return redirect('/showrec');
    }
    public function signup(Request $req)
    {
        $aa = new register();
        $aa->name = $req->name;
        $aa->email = $req->email;
        $aa->contact = $req->contact;
        $aa->date = $req->date;
        $aa->city = $req->city;
        $aa -> save();
        return redirect('/regrec');
    }
}