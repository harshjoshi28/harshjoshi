<!DOCTYPE html>  
<html lang="en">  
  <head>  
     <title>Laravel DB Query</title>  
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"/>  
  </head>  
  <body>
<div class="container">  
<h1>Laravel DB Query</h1>
<form action="" method="POST">
    <?php echo csrf_field(); ?>
    <div class="form-group">
    <input type = "hidden" name = "id" value="<?php echo e($users->id); ?>">  
  </div>
  <div class="form-group">  
    <label for="name">Name</label>  
    <input type="text" class="form-control" value="<?php echo e($users->name); ?>" name="name" id="exampleInputEmail1" placeholder="Enter Your Name">  
  </div>  
  <div class="form-group">  
    <label for="email">Email</label>  
    <input type="email" class="form-control" value="<?php echo e($users->email); ?>" name="email" id="email" placeholder="Enter Your EMail">  
  </div>  
  <div class="form-group">  
    <label for="name">Contact</label>  
    <input type="number" class="form-control" value="<?php echo e($users->contact); ?>" name="contact" id="contact" placeholder="Enter Your Contact">  
  </div> 
  <button type="submit" class="btn btn-primary">Update</button>
  <button type="reset" class="btn btn-danger">Clear</button>
</form>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>  
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>  
  </body>  
</html><?php /**PATH C:\laragon\www\larodb\resources\views/update.blade.php ENDPATH**/ ?>