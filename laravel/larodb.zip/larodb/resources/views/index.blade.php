<!DOCTYPE html>  
<html lang="en">  
  <head>  
     <title>Laravel DB Query</title>  
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"/>  
  </head>  
  <body>
<div class="container">  
<h1>Laravel DB Query</h1>
<form action="/add" method="POST">
    @csrf 
  <div class="form-group">  
    <label for="name">Name</label>  
    <input type="text" class="form-control" name="name" id="exampleInputEmail1" placeholder="Enter Your Name">  
  </div>  
  <div class="form-group">  
    <label for="email">Email</label>  
    <input type="email" class="form-control" name="email" id="email" placeholder="Enter Your EMail">  
  </div>  
  <div class="form-group">  
    <label for="name">Contact</label>  
    <input type="number" class="form-control" name="contact" id="contact" placeholder="Enter Your Contact">  
  </div> 
  <button type="submit" class="btn btn-primary">Register</button>
  <button type="reset" class="btn btn-danger">Clear</button>
</form> 
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>  
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>  
  </body>  
</html>  