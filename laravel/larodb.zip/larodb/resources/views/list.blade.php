<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List</title>
</head>
<body>
    <table align="center" border="1">
        <tr>
            <td>Name</td>
            <td>Email</td>
            <td>Contact</td>
            <td>Update</td>
            <td>Delete</td>
        </tr>
        @foreach($users as $a)
        <tr>
            <td>{{$a -> name}}</td>
            <td>{{$a -> email}}</td>
            <td>{{$a -> contact}}</td>
            <td><a href="update/{{ $a->id }}">Update</a></td>
            <td><a href='delete/{{ $a->id }}'>Delete</a></td>
        </tr>
        @endforeach
    </table>
</body>
</html>