<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CrudController extends Controller
{
    public function addrec(Request $request)
    {
        $name = $request->name;
        $email = $request->email;
        $contact = $request->contact;

        DB::insert('insert into stud (name,email,contact) values(?,?,?)',[$name,$email,$contact]);
        
        return view('index');
    }
    public function listrec()
    {
        $a =  DB::table('stud')->get();
        return view('list', ['users' => $a]);
    }
    public function delete($id)
    {
        DB::delete('delete from stud where id = ?',[$id]);
        $a = DB::table('stud')->get();
        return view('list', ['users' => $a]);
    }
    public function update($id)
    {
        $a =  DB::table('stud')->find($id);
        return view('update',['users'=>$a]);
    }
    public function updateaction(Request $request)
    {
        $id = $request->id;
        $name = $request->name;
        $email = $request->email;
        $contact = $request->contact;

        $a = DB::update('update stud set name = ?,email = ?,contact = ? where id = ?',[$name,$email,$contact,$id]);
        echo "Updated!";
        //return view('list', ['users' => $a]);
    }
}
